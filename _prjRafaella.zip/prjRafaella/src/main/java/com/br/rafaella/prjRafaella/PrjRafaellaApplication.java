package com.br.rafaella.prjRafaella;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjRafaellaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjRafaellaApplication.class, args);
	}

}
